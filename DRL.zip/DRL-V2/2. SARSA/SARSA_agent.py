import random
import torch.nn as nn
import torch
import torch.optim as optim



class Q_net(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(Q_net, self).__init__()
        self.f1 = nn.Linear(input_dim, 128)
        self.f2 = nn.Linear(128, 128)
        self.f3 = nn.Linear(128, output_dim)

    def forward(self, x):
        x = torch.relu(self.f1(x))
        x = torch.relu(self.f2(x))
        return self.f3(x)



class Agent:
    def __init__(self, state_dim, action_dim, lr, buffer_size, batch_size, gamma, update_interval):
        self.q_net = Q_net(state_dim, action_dim)
        self.target_q_net = Q_net(state_dim, action_dim)
        self.target_q_net.load_state_dict(self.q_net.state_dict())
        self.q_net_optimizer = optim.AdamW(self.q_net.parameters(), lr=lr, amsgrad=True)

        self.batch_size = batch_size
        self.gamma = gamma
        self.update_interval = update_interval
        self.update_count = 0
        self.action_dim = action_dim

    def get_action(self, state, epsilon):
        # SARSA也使用ε-greedy策略选择动作
        random_sample = random.random()
        if random_sample <= epsilon:
            return random.randint(0, self.action_dim - 1)
        else:
            with torch.no_grad():
                return self.q_net(torch.FloatTensor(state)).max(0).indices.item()

    

    def update_step(self, state, action, reward, next_state, next_action, done):
        s = torch.FloatTensor(state).unsqueeze(0)
        ns = torch.FloatTensor(next_state).unsqueeze(0)
        a = torch.tensor([[action]])
        na = torch.tensor([[next_action]])
        r = torch.FloatTensor([[reward]])
        d = torch.FloatTensor([[1.0 if done else 0.0]])

        q = self.q_net(s).gather(1, a)
        with torch.no_grad():
            next_q = self.target_q_net(ns).gather(1, na)
            target_q = r + (1 - d) * self.gamma * next_q

        loss = nn.MSELoss()(q, target_q)
        self.q_net_optimizer.zero_grad()
        loss.backward()
        self.q_net_optimizer.step()

        self.update_count += 1
        if self.update_count % self.update_interval == 0:
            self.target_q_net.load_state_dict(self.q_net.state_dict())
