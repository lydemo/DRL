import os.path
import random
import gymnasium as gym
import numpy as np
import argparse
import sys
import time

# 添加项目根目录到Python搜索路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入SARSA智能体
from SARSA_agent import Agent
from common.tools import plot_reward, save_model


def to_one_hot(state, num_states):
    """将离散状态转换为one-hot向量"""
    one_hot = np.zeros(num_states)
    one_hot[state] = 1.0
    return one_hot


def init_parameters():
    """
    Initialize the parameters required for the algorithm.
    """
    parser = argparse.ArgumentParser(description="SARSA Hyperparameters")
    parser.add_argument("--env_name", type=str, default="CliffWalking-v1", help="Environment name")
    parser.add_argument("--episode_length", type=int, default=500, help="Maximum episodes")
    parser.add_argument("--step_length", type=int, default=100, help="Maximum steps per episode")
    parser.add_argument("--epsilon_start", type=float, default=1, help="Initial value of epsilon in epsilon-greedy exploration")
    parser.add_argument("--epsilon_end", type=float, default=0.02, help="Final value of epsilon in epsilon-greedy exploration")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate for training the Q-network")
    parser.add_argument("--buffer_size", type=int, default=10000, help="The size of replay buffer")
    parser.add_argument("--batch_size", type=int, default=128, help="Batch size for training")
    parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor for rewards")
    parser.add_argument("--interval", type=int, default=100, help="Training interval of the target Q-network")
    arg = parser.parse_args()
    print(arg)
    return arg


if __name__ == '__main__':
    args = init_parameters()
    
    # 创建环境
    env = gym.make(args.env_name)
    
    # 检查环境类型并设置状态维度
    if hasattr(env.observation_space, 'n'):  # 离散观测空间
        state_dim = env.observation_space.n
        is_discrete = True
    else:  # 连续观测空间
        state_dim = env.observation_space.shape[0]
        is_discrete = False
    
    action_dim = env.action_space.n

    # 创建SARSA智能体
    agent = Agent(state_dim, action_dim, args.lr, args.buffer_size, args.batch_size, args.gamma, args.interval)

    reward_list = []
    
    for episode_i in range(args.episode_length):
        # 处理gym版本兼容性问题
        try:
            raw_state, info = env.reset()
        except ValueError:
            raw_state = env.reset()
            info = {}
        
        # 处理离散状态
        if is_discrete:
            state = to_one_hot(raw_state, state_dim)
        else:
            state = raw_state
        
        episode_reward = 0

        # epsilon衰减
        epsilon = np.interp(x=episode_i*args.step_length, 
                            xp=[0, args.episode_length*args.step_length/2],
                            fp=[args.epsilon_start, args.epsilon_end])
        
        # 选择初始动作
        action = agent.get_action(state, epsilon)

        for step_i in range(args.step_length):
            # 执行动作
            try:
                raw_next_state, reward, terminated, truncated, info_ = env.step(action)
                done = terminated or truncated
            except ValueError:
                # 兼容旧版本gym
                raw_next_state, reward, done, info_ = env.step(action)

            # 处理下一个状态
            if is_discrete:
                next_state = to_one_hot(raw_next_state, state_dim)
            else:
                next_state = raw_next_state

            # 选择下一个动作（SARSA的核心：在更新之前就选择下一个动作）
            next_action = agent.get_action(next_state, epsilon)

            agent.update_step(state, action, reward, next_state, next_action, done)

            # 转移到下一个状态和动作
            state = next_state
            action = next_action
            
            episode_reward += reward
            
            if done:
                break

        print(f"Episode: {episode_i+1}, Reward: {round(episode_reward, 3)}, Epsilon: {epsilon:.4f}")
        reward_list.append(episode_reward)

    # 保存模型
    save_model(os.path.dirname(os.path.realpath(__file__)), agent.q_net.state_dict(), 'sarsa_q')
    
    # 绘制并保存奖励曲线
    import matplotlib.pyplot as plt
    from common.tools import moving_average, compute_std
    
    # 计算移动平均和标准差
    moving_reward_list = moving_average(reward_list, 30)
    std_reward_list = compute_std(reward_list, 30)
    
    # 绘制奖励曲线
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(moving_reward_list)), moving_reward_list, color='b', label='Moving Average')
    plt.fill_between(range(len(moving_reward_list)), 
                     moving_reward_list - std_reward_list, 
                     moving_reward_list + std_reward_list,
                     color='b', alpha=0.2, label='Standard Deviation')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title('SARSA Training Rewards - CliffWalking-v0')
    plt.legend()
    plt.grid(True)
    
    # 保存图像到reward_plot文件夹
    reward_plot_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'reward_plot')
    os.makedirs(reward_plot_dir, exist_ok=True)
    timestamp = time.strftime("%Y%m%d%H%M%S")
    plt.savefig(os.path.join(reward_plot_dir, f'sarsa_rewards_{timestamp}.png'), dpi=300, bbox_inches='tight')
    plt.show()
    
    print("SARSA training completed!")

    try:
        test_env = gym.make(args.env_name, render_mode="human")
    except Exception:
        test_env = gym.make(args.env_name)
    test_episodes = 3
    for episode_i in range(test_episodes):
        try:
            raw_state, _ = test_env.reset()
        except Exception:
            raw_state = test_env.reset()
        if is_discrete:
            state = to_one_hot(raw_state, state_dim)
        else:
            state = raw_state
        ep_reward = 0.0
        action = agent.get_action(state, 0.0)
        for _ in range(args.step_length):
            try:
                raw_next_state, reward, terminated, truncated, _ = test_env.step(action)
                done = terminated or truncated
            except Exception:
                raw_next_state, reward, done, _ = test_env.step(action)
            if is_discrete:
                next_state = to_one_hot(raw_next_state, state_dim)
            else:
                next_state = raw_next_state
            next_action = agent.get_action(next_state, 0.0)
            state = next_state
            action = next_action
            ep_reward += reward
            try:
                test_env.render()
            except Exception:
                pass
            if done:
                break
        print(f"Test Episode {episode_i+1}/{test_episodes}, Reward: {round(ep_reward, 3)}")
    test_env.close()
