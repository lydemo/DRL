import os
import time
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Normal


class ContinuousActor(nn.Module):
    """Actor 网络：用于连续动作空间，输出动作均值和标准差"""
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.mean = nn.Linear(hidden_dim, action_dim)
        self.log_std = nn.Linear(hidden_dim, action_dim)
        
        # 初始化参数
        self.mean.weight.data.uniform_(-0.1, 0.1)
        self.mean.bias.data.uniform_(-0.1, 0.1)
        self.log_std.weight.data.uniform_(-0.1, 0.1)
        self.log_std.bias.data.uniform_(-0.1, 0.1)

    def forward(self, state: torch.FloatTensor):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        mean = self.mean(x)
        log_std = self.log_std(x)
        # 限制标准差范围，避免数值不稳定
        log_std = torch.clamp(log_std, -20, 2)
        std = torch.exp(log_std)
        return mean, std


class ContinuousCritic(nn.Module):
    """Critic 网络：输入连续状态，输出状态价值 V(s)"""
    def __init__(self, state_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.v = nn.Linear(hidden_dim, 1)

    def forward(self, state: torch.FloatTensor):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        return self.v(x).squeeze(-1)


@dataclass
class Transition:
    state: np.ndarray  # 连续状态向量
    action: np.ndarray  # 连续动作向量
    log_prob: float
    value: float
    reward: float
    done: bool


class RolloutBuffer:
    """用于存储一个或多个 episode 的采样数据，并支持计算优势/回报"""
    def __init__(self):
        self.states: List[int] = []
        self.actions: List[int] = []
        self.log_probs: List[float] = []
        self.values: List[float] = []
        self.rewards: List[float] = []
        self.dones: List[bool] = []
        self.advantages: List[float] = []
        self.returns: List[float] = []

    def __len__(self):
        return len(self.states)

    def add(self, transition: Transition):
        self.states.append(transition.state)
        self.actions.append(transition.action)
        self.log_probs.append(transition.log_prob)
        self.values.append(transition.value)
        self.rewards.append(transition.reward)
        self.dones.append(transition.done)

    def clear(self):
        self.states.clear()
        self.actions.clear()
        self.log_probs.clear()
        self.values.clear()
        self.rewards.clear()
        self.dones.clear()
        self.advantages.clear()
        self.returns.clear()

    def compute_advantages_and_returns(self, gamma: float, lam: float, last_value: float = 0.0):
        """
        使用 GAE(Generalized Advantage Estimation) 计算优势和回报。
        对于 episode 结束时，last_value 设为 0；如需跨 episode 训练，可在未结束时传入 bootstrap 的 last_value。
        """
        T = len(self.rewards)
        self.advantages = [0.0] * T
        self.returns = [0.0] * T

        gae = 0.0
        for t in reversed(range(T)):
            next_value = last_value if t == T - 1 else self.values[t + 1]
            delta = self.rewards[t] + gamma * next_value * (1 - float(self.dones[t])) - self.values[t]
            gae = delta + gamma * lam * (1 - float(self.dones[t])) * gae
            self.advantages[t] = gae
            self.returns[t] = self.advantages[t] + self.values[t]


class PPOAgent:
    """PPO 智能体（连续动作），适配 LunarLander-v2 等连续环境"""
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        actor_lr: float = 3e-4,
        critic_lr: float = 1e-3,
        gamma: float = 0.99,
        lam: float = 0.95,
        clip_eps: float = 0.2,
        entropy_coef: float = 0.01,
        update_epochs: int = 4,
        batch_size: int = 256,
    ):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.lam = lam
        self.clip_eps = clip_eps
        self.entropy_coef = entropy_coef
        self.update_epochs = update_epochs
        self.batch_size = batch_size

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.actor = ContinuousActor(state_dim, action_dim).to(self.device)
        self.critic = ContinuousCritic(state_dim).to(self.device)

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=critic_lr)

        self.buffer = RolloutBuffer()

    def get_action(self, state: np.ndarray, deterministic: bool = False) -> Tuple[np.ndarray, float, float]:
        """根据当前状态选择动作，返回 (action, log_prob, value)"""
        s = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            mean, std = self.actor(s)
            dist = Normal(mean, std)
            if deterministic:
                action = mean
            else:
                action = dist.sample()
            log_prob = dist.log_prob(action).sum(dim=-1)  # 多维动作的log_prob求和
            value = self.critic(s)
        return action.squeeze(0).cpu().numpy(), float(log_prob.item()), float(value.item())

    def update(self) -> Tuple[float, float]:
        """使用当前 buffer 数据执行 PPO 更新，返回 (actor_loss, critic_loss) 的均值"""
        if len(self.buffer) == 0:
            return 0.0, 0.0

        states = torch.FloatTensor(np.array(self.buffer.states)).to(self.device)
        actions = torch.FloatTensor(np.array(self.buffer.actions)).to(self.device)
        old_log_probs = torch.FloatTensor(self.buffer.log_probs).to(self.device)
        returns = torch.FloatTensor(self.buffer.returns).to(self.device)
        advantages = torch.FloatTensor(self.buffer.advantages).to(self.device)

        # 归一化优势
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        N = states.size(0)
        idxs = np.arange(N)
        actor_loss_acc = 0.0
        critic_loss_acc = 0.0
        total_updates = 0

        for _ in range(self.update_epochs):
            np.random.shuffle(idxs)
            for start in range(0, N, self.batch_size):
                end = start + self.batch_size
                batch_idx = idxs[start:end]
                b_states = states[batch_idx]
                b_actions = actions[batch_idx]
                b_old_log_probs = old_log_probs[batch_idx]
                b_returns = returns[batch_idx]
                b_advantages = advantages[batch_idx]

                # 更新 Actor
                mean, std = self.actor(b_states)
                dist = Normal(mean, std)
                new_log_probs = dist.log_prob(b_actions).sum(dim=-1)  # 多维动作求和
                ratio = torch.exp(new_log_probs - b_old_log_probs)
                surr1 = ratio * b_advantages
                surr2 = torch.clamp(ratio, 1.0 - self.clip_eps, 1.0 + self.clip_eps) * b_advantages
                policy_loss = -torch.min(surr1, surr2).mean()
                entropy = dist.entropy().sum(dim=-1).mean()  # 多维动作熵求和
                actor_loss = policy_loss - self.entropy_coef * entropy

                self.actor_optimizer.zero_grad()
                actor_loss.backward()
                self.actor_optimizer.step()

                # 更新 Critic
                values = self.critic(b_states)
                critic_loss = F.mse_loss(values, b_returns)
                self.critic_optimizer.zero_grad()
                critic_loss.backward()
                self.critic_optimizer.step()

                actor_loss_acc += float(actor_loss.item())
                critic_loss_acc += float(critic_loss.item())
                total_updates += 1

        # 清空 buffer
        self.buffer.clear()

        if total_updates == 0:
            return 0.0, 0.0

        return actor_loss_acc / total_updates, critic_loss_acc / total_updates

    def save_model(self, filepath: str):
        torch.save({
            'actor_state_dict': self.actor.state_dict(),
            'critic_state_dict': self.critic.state_dict(),
            'actor_optimizer_state_dict': self.actor_optimizer.state_dict(),
            'critic_optimizer_state_dict': self.critic_optimizer.state_dict(),
        }, filepath)

    def load_model(self, filepath: str):
        checkpoint = torch.load(filepath, map_location=self.device)
        self.actor.load_state_dict(checkpoint['actor_state_dict'])
        self.critic.load_state_dict(checkpoint['critic_state_dict'])
        self.actor_optimizer.load_state_dict(checkpoint['actor_optimizer_state_dict'])
        self.critic_optimizer.load_state_dict(checkpoint['critic_optimizer_state_dict'])