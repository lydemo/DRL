import os
import sys
import time
import argparse
import numpy as np
import gymnasium as gym
import matplotlib.pyplot as plt

# 添加项目根目录到Python搜索路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入PPO智能体和工具函数
from PPO_agent import PPOAgent, Transition
from common.tools import moving_average, compute_std


def init_parameters():
    """初始化算法参数"""
    parser = argparse.ArgumentParser(description="PPO Hyperparameters (LunarLander)")
    parser.add_argument("--env_name", type=str, default="LunarLander-v3",
                        help="Environment name")
    parser.add_argument("--episodes", type=int, default=300,
                        help="Maximum training episodes")
    parser.add_argument("--max_steps", type=int, default=1000,
                        help="Maximum steps per episode")
    parser.add_argument("--actor_lr", type=float, default=3e-4,
                        help="Learning rate for Actor network")
    parser.add_argument("--critic_lr", type=float, default=1e-3,
                        help="Learning rate for Critic network")
    parser.add_argument("--gamma", type=float, default=0.99,
                        help="Discount factor")
    parser.add_argument("--lam", type=float, default=0.95,
                        help="GAE lambda")
    parser.add_argument("--clip_eps", type=float, default=0.2,
                        help="PPO clip epsilon")
    parser.add_argument("--entropy_coef", type=float, default=0.01,
                        help="Entropy coefficient for exploration")
    parser.add_argument("--update_epochs", type=int, default=4,
                        help="PPO update epochs per rollout")
    parser.add_argument("--batch_size", type=int, default=64,
                        help="Minibatch size for PPO updates")
    parser.add_argument("--save_freq", type=int, default=100,
                        help="Model save frequency (episodes)")

    args = parser.parse_args()

    print("PPO Training Parameters (LunarLander):")
    print(f"Environment: {args.env_name}")
    print(f"Episodes: {args.episodes}")
    print(f"Actor LR: {args.actor_lr}, Critic LR: {args.critic_lr}")
    print(f"Gamma: {args.gamma}, Lambda: {args.lam}, Clip: {args.clip_eps}")
    print(f"Batch Size: {args.batch_size}, Update Epochs: {args.update_epochs}")
    print("-" * 50)
    return args


def plot_training_results(episode_rewards, actor_losses, critic_losses, env_name):
    timestamp = time.strftime("%Y%m%d%H%M%S")
    moving_rewards = moving_average(episode_rewards, window_size=30)
    std_rewards = compute_std(episode_rewards, window_size=30)
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(moving_rewards)), moving_rewards, color='b', label='Moving Average')
    plt.fill_between(range(len(moving_rewards)),
                     moving_rewards - std_rewards,
                     moving_rewards + std_rewards,
                     color='b', alpha=0.2, label='Standard Deviation')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title(f'PPO Training Rewards - {env_name}')
    plt.legend()
    plt.grid(True)
    reward_plot_dir = os.path.join(os.path.dirname(__file__), 'reward_plot')
    os.makedirs(reward_plot_dir, exist_ok=True)
    plot_path = os.path.join(reward_plot_dir, f'ppo_rewards_{timestamp}.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    print(f"训练结果图已保存: {plot_path}")
    plt.show()


def train_ppo():
    args = init_parameters()

    # 创建环境（LunarLander 连续动作版本）
    env = gym.make(args.env_name, continuous=True)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]

    print(f"State dimension: {state_dim}")
    print(f"Action dimension: {action_dim}")
    print("-" * 50)

    agent = PPOAgent(
        state_dim=state_dim,
        action_dim=action_dim,
        actor_lr=args.actor_lr,
        critic_lr=args.critic_lr,
        gamma=args.gamma,
        lam=args.lam,
        clip_eps=args.clip_eps,
        entropy_coef=args.entropy_coef,
        update_epochs=args.update_epochs,
        batch_size=args.batch_size,
    )

    episode_rewards = []
    actor_losses = []
    critic_losses = []
    best_reward = -np.inf

    print("开始 PPO 训练（LunarLander）...")
    start_time = time.time()

    for episode in range(args.episodes):
        state, _ = env.reset()
        episode_reward = 0.0
        steps = 0

        for step in range(args.max_steps):
            action, log_prob, value = agent.get_action(state, deterministic=False)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            agent.buffer.add(Transition(
                state=state,
                action=action,
                log_prob=log_prob,
                value=value,
                reward=reward,
                done=done,
            ))

            state = next_state
            episode_reward += reward
            steps += 1

            if done:
                break

        # Episode 结束，计算优势与回报（episodic：last_value=0）
        agent.buffer.compute_advantages_and_returns(gamma=args.gamma, lam=args.lam, last_value=0.0)
        a_loss, c_loss = agent.update()

        episode_rewards.append(episode_reward)
        actor_losses.append(a_loss)
        critic_losses.append(c_loss)
        best_reward = max(best_reward, episode_reward)

        print(f"Episode {episode + 1}/{args.episodes}, Reward: {episode_reward:.2f}, Steps: {steps}")

        if (episode + 1) % 50 == 0:
            avg_reward = np.mean(episode_rewards[-50:])
            print(f"Episode {episode + 1}/{args.episodes}")
            print(f"Average Reward (last 50): {avg_reward:.2f}")
            print(f"Best Reward: {best_reward:.2f}")
            print(f"Actor Loss: {actor_losses[-1]:.4f}, Critic Loss: {critic_losses[-1]:.4f}")
            print("-" * 50)

        # 保存模型
        if (episode + 1) % args.save_freq == 0:
            timestamp = time.strftime("%Y%m%d%H%M%S")
            model_path = os.path.join(os.path.dirname(__file__), 'models', f'ppo_model_{timestamp}.pth')
            agent.save_model(model_path)
            print(f"Model saved: {model_path}")

    training_time = time.time() - start_time
    print("\nPPO训练完成！")
    print(f"训练时间: {training_time:.2f}秒")
    print(f"最佳奖励: {best_reward:.2f}")

    timestamp = time.strftime("%Y%m%d%H%M%S")
    final_model_path = os.path.join(os.path.dirname(__file__), 'models', f'ppo_final_{timestamp}.pth')
    agent.save_model(final_model_path)
    print(f"最终模型已保存: {final_model_path}")

    plot_training_results(episode_rewards, actor_losses, critic_losses, args.env_name)

    try:
        test_env = gym.make(args.env_name, render_mode="human", continuous=True)
    except Exception:
        test_env = gym.make(args.env_name, continuous=True)
    test_episodes = 3
    for episode in range(test_episodes):
        state, _ = test_env.reset()
        ep_reward = 0.0
        for _ in range(args.max_steps):
            action, _, _ = agent.get_action(state, deterministic=True)
            step_ret = test_env.step(action)
            if len(step_ret) == 5:
                next_state, reward, terminated, truncated, _ = step_ret
                done = terminated or truncated
            else:
                next_state, reward, done, _ = step_ret
            ep_reward += reward
            state = next_state
            try:
                test_env.render()
            except Exception:
                pass
            if done:
                break
        print(f"Test Episode {episode+1}/{test_episodes}, Reward: {ep_reward:.2f}")
    test_env.close()

    env.close()
    return agent, episode_rewards


if __name__ == '__main__':
    train_ppo()
