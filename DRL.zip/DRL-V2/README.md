Using venv:

1. Create a virtual environment: > python3 -m venv myENV
2. Activate: > source myENV/bin/activate
3. Check the python version: >which python
4. Deactivate: >deactivate
