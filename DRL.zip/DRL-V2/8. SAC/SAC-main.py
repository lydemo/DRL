import argparse
import gymnasium as gym
import os
import sys
import time
import numpy as np
import matplotlib.pyplot as plt
import importlib.util

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入SAC-agent.py中的SAC_Agent类
spec = importlib.util.spec_from_file_location("SAC_Agent", "SAC-agent.py")
SAC_Agent_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(SAC_Agent_module)
SAC_Agent = SAC_Agent_module.SAC_Agent
from common.tools import moving_average, compute_std, save_model


def init_parameters():
    """
    Initialize the parameters required for the SAC algorithm.
    """
    parser = argparse.ArgumentParser(description="SAC Hyperparameters for LunarLanderContinuous-v2")
    parser.add_argument("--env_name", type=str, default="LunarLanderContinuous-v3", help="Environment name")
    parser.add_argument("--episode_length", type=int, default=300, help="Maximum episodes")
    parser.add_argument("--max_episode_steps", type=int, default=1000, help="Maximum steps per episode")
    parser.add_argument("--actor_lr", type=float, default=3e-4, help="Learning rate for actor network")
    parser.add_argument("--critic_lr", type=float, default=3e-4, help="Learning rate for critic network")
    parser.add_argument("--entropy_lr", type=float, default=3e-4, help="Learning rate for entropy tuning")
    parser.add_argument("--buffer_size", type=int, default=100000, help="The size of replay buffer")
    parser.add_argument("--batch_size", type=int, default=256, help="Batch size for training")
    parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor for rewards")
    parser.add_argument("--tau", type=float, default=0.005, help="Soft update parameter for target network")
    parser.add_argument("--start_steps", type=int, default=10000, help="Steps for random action at beginning")
    parser.add_argument("--update_after", type=int, default=1000, help="Steps before starting updates")
    parser.add_argument("--update_every", type=int, default=50, help="Update frequency")
    parser.add_argument("--save_interval", type=int, default=100, help="Model saving interval (episodes)")
    parser.add_argument("--eval_interval", type=int, default=50, help="Evaluation interval (episodes)")
    parser.add_argument("--eval_episodes", type=int, default=10, help="Number of evaluation episodes")
    
    arg = parser.parse_args()
    print("SAC Training Parameters:")
    print(f"Environment: {arg.env_name}")
    print(f"Episodes: {arg.episode_length}")
    print(f"Max Episode Steps: {arg.max_episode_steps}")
    print(f"Actor LR: {arg.actor_lr}")
    print(f"Critic LR: {arg.critic_lr}")
    print(f"Entropy LR: {arg.entropy_lr}")
    print(f"Buffer Size: {arg.buffer_size}")
    print(f"Batch Size: {arg.batch_size}")
    print(f"Gamma: {arg.gamma}")
    print(f"Tau: {arg.tau}")
    print("-" * 50)
    return arg


def evaluate_policy(agent, env, eval_episodes=10):
    """
    Evaluate the policy performance
    """
    eval_rewards = []
    
    for _ in range(eval_episodes):
        state, _ = env.reset()
        episode_reward = 0
        done = False
        
        while not done:
            # Use deterministic action for evaluation
            action = agent.get_action(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            state = next_state
            episode_reward += reward
        
        eval_rewards.append(episode_reward)
    
    return np.mean(eval_rewards), np.std(eval_rewards)


def plot_training_results(reward_list, eval_rewards, eval_episodes_list, alpha_values, 
                         env_name, total_episodes):
    timestamp = time.strftime("%Y%m%d%H%M%S")
    moving_rewards = moving_average(reward_list, window_size=30)
    std_rewards = compute_std(reward_list, window_size=30)
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(moving_rewards)), moving_rewards, color='b', label='Moving Average')
    plt.fill_between(range(len(moving_rewards)), 
                     np.array(moving_rewards) - np.array(std_rewards), 
                     np.array(moving_rewards) + np.array(std_rewards),
                     color='b', alpha=0.2, label='Standard Deviation')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title(f'SAC Training Rewards - {env_name}')
    plt.legend()
    plt.grid(True)
    reward_plot_dir = os.path.join(os.path.dirname(__file__), 'reward_plot')
    os.makedirs(reward_plot_dir, exist_ok=True)
    timestamp = time.strftime("%Y%m%d%H%M%S")
    plot_path = os.path.join(reward_plot_dir, f'sac_rewards_{timestamp}.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    print(f"训练结果图已保存: {plot_path}")
    plt.show()


if __name__ == '__main__':
    args = init_parameters()
    
    # Create environments
    env = gym.make(args.env_name)
    eval_env = gym.make(args.env_name)
    
    # Get environment information
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    max_action = float(env.action_space.high[0])
    
    print(f"State dimension: {state_dim}")
    print(f"Action dimension: {action_dim}")
    print(f"Max action: {max_action}")
    print("-" * 50)
    
    # Create SAC agent
    agent = SAC_Agent(state_dim, action_dim, max_action, args.actor_lr, args.critic_lr, 
                     args.entropy_lr, args.buffer_size, args.batch_size, args.gamma, args.tau)

    # Training records
    reward_list = []
    eval_rewards = []
    eval_episodes_list = []
    actor_losses = []
    critic_losses = []
    alpha_values = []
    best_eval_reward = float('-inf')
    
    total_steps = 0
    
    print("开始SAC训练...")
    start_time = time.time()
    
    for episode_i in range(args.episode_length):
        state, _ = env.reset()
        episode_reward = 0
        episode_steps = 0

        for step_i in range(args.max_episode_steps):
            # Select action
            if total_steps < args.start_steps:
                # Random action for exploration at the beginning
                action = env.action_space.sample()
            else:
                action = agent.get_action(state)
            
            # Execute action
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            # Store transition
            agent.replay_buffer.store_transition(state, action, next_state, reward, done)
            state = next_state
            episode_reward += reward
            episode_steps += 1
            total_steps += 1
            
            # Update agent
            if total_steps >= args.update_after and total_steps % args.update_every == 0:
                for _ in range(args.update_every):
                    agent.update()
                
                # Record alpha value
                alpha_values.append(agent.alpha.item())
            
            if done:
                break

        print(f"Episode: {episode_i + 1}, Reward: {episode_reward:.2f}, Steps: {episode_steps}, Total Steps: {total_steps}")
        reward_list.append(episode_reward)
        
        # Evaluation
        if (episode_i + 1) % args.eval_interval == 0:
            eval_mean, eval_std = evaluate_policy(agent, eval_env, args.eval_episodes)
            eval_rewards.append(eval_mean)
            eval_episodes_list.append(episode_i + 1)
            
            if eval_mean > best_eval_reward:
                best_eval_reward = eval_mean
                # Save best model
                timestamp = time.strftime("%Y%m%d%H%M%S")
                best_model_path = os.path.join(os.path.dirname(__file__), 'models', f'sac_best_{timestamp}.pth')
                os.makedirs(os.path.dirname(best_model_path), exist_ok=True)
                save_model(os.path.dirname(os.path.realpath(__file__)), agent.actor.state_dict(), f'sac_best_{timestamp}')
                print(f"新的最佳模型已保存，评估奖励: {eval_mean:.2f} ± {eval_std:.2f}")
            
            print(f"Episode {episode_i + 1}: Eval Reward = {eval_mean:.2f} ± {eval_std:.2f}, Best = {best_eval_reward:.2f}")
        
        # Save model periodically
        if (episode_i + 1) % args.save_interval == 0:
            timestamp = time.strftime("%Y%m%d%H%M%S")
            save_model(os.path.dirname(os.path.realpath(__file__)), agent.actor.state_dict(), f'sac_episode_{episode_i+1}_{timestamp}')
            print(f"模型已保存 (Episode {episode_i + 1})")
    
    # Training completed
    end_time = time.time()
    training_time = end_time - start_time
    
    print(f"\nSAC训练完成!")
    print(f"训练时间: {training_time:.2f}秒")
    print(f"总回合数: {args.episode_length}")
    print(f"总步数: {total_steps}")
    print(f"最佳评估奖励: {best_eval_reward:.2f}")
    
    # Save final model
    timestamp = time.strftime("%Y%m%d%H%M%S")
    save_model(os.path.dirname(os.path.realpath(__file__)), agent.actor.state_dict(), f'sac_final_{timestamp}')
    print(f"最终模型已保存")
    
    try:
        test_env = gym.make(args.env_name, render_mode="human")
    except Exception:
        test_env = gym.make(args.env_name)
    test_episodes = 3
    for episode in range(test_episodes):
        state, _ = test_env.reset()
        ep_reward = 0.0
        steps = 0
        for _ in range(args.max_episode_steps):
            action = agent.get_action(state)
            step_ret = test_env.step(action)
            if len(step_ret) == 5:
                next_state, reward, terminated, truncated, _ = step_ret
                done = terminated or truncated
            else:
                next_state, reward, done, _ = step_ret
            ep_reward += reward
            steps += 1
            state = next_state
            try:
                test_env.render()
            except Exception:
                pass
            if done:
                break
        print(f"Test Episode {episode+1}/{test_episodes}, Reward: {ep_reward:.2f}, Steps: {steps}")
    test_env.close()

    # Close environments
    env.close()
    eval_env.close()
    
    # Plot and save training results
    plot_training_results(reward_list, eval_rewards, eval_episodes_list, alpha_values, 
                         args.env_name, args.episode_length)
