import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from torch.distributions import Normal
from collections import deque


class ActorNet(nn.Module):
    """Actor网络：输出连续动作的均值和标准差"""
    def __init__(self, state_dim, action_dim, max_action):
        super(ActorNet, self).__init__()
        self.f1 = nn.Linear(state_dim, 256)
        self.f2 = nn.Linear(256, 256)
        self.mean = nn.Linear(256, action_dim)
        self.log_std = nn.Parameter(torch.zeros(1, action_dim))
        self.max_action = max_action

    def forward(self, state):
        x = F.relu(self.f1(state))
        x = F.relu(self.f2(x))
        mean = torch.tanh(self.mean(x)) * self.max_action
        return mean

    def get_dist(self, state):
        """获取动作分布"""
        mean = self.forward(state)
        std = torch.exp(self.log_std).expand_as(mean)
        dist = Normal(mean, std)
        return dist


class CriticNet(nn.Module):
    """Critic网络：估计状态价值函数V(s)"""
    def __init__(self, state_dim):
        super(CriticNet, self).__init__()
        self.f1 = nn.Linear(state_dim, 256)
        self.f2 = nn.Linear(256, 256)
        self.f3 = nn.Linear(256, 1)

    def forward(self, state):
        x = F.relu(self.f1(state))
        x = F.relu(self.f2(x))
        value = self.f3(x)
        return value


class Memory:
    """经验回放缓冲区"""
    def __init__(self, capacity):
        self.memory = deque([], maxlen=capacity)

    def __len__(self):
        return len(self.memory)

    def store_transition(self, state, action, log_prob, next_state, reward, done):
        self.memory.append((state, action, log_prob, next_state, reward, done))

    def sample(self, batch_size):
        import random
        return random.sample(self.memory, batch_size)

    def clear(self):
        self.memory.clear()


class A2CAgent:
    """A2C (Advantage Actor-Critic) 智能体"""
    def __init__(self, state_dim, action_dim, max_action, actor_lr=3e-4, critic_lr=1e-3, 
                 gamma=0.99, buffer_size=10000, batch_size=64, entropy_coef=0.01):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.max_action = max_action
        self.gamma = gamma
        self.batch_size = batch_size
        self.entropy_coef = entropy_coef

        # 创建Actor和Critic网络
        self.actor = ActorNet(state_dim, action_dim, max_action)
        self.critic = CriticNet(state_dim)

        # 优化器
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=critic_lr)

        # 经验回放缓冲区
        self.memory = Memory(buffer_size)

        # 设备
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.actor.to(self.device)
        self.critic.to(self.device)

    def get_action(self, state):
        """根据当前状态选择动作"""
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            dist = self.actor.get_dist(state)
            action = dist.sample()
            log_prob = dist.log_prob(action).sum(dim=-1)
            
        return action.cpu().numpy().flatten(), log_prob.cpu().numpy().item()

    def update(self):
        """更新Actor和Critic网络"""
        if len(self.memory) < self.batch_size:
            return

        # 从经验回放缓冲区采样
        batch = self.memory.sample(self.batch_size)
        states, actions, log_probs, next_states, rewards, dones = zip(*batch)

        states = torch.FloatTensor(np.array(states)).to(self.device)
        actions = torch.FloatTensor(np.array(actions)).to(self.device)
        log_probs = torch.FloatTensor(log_probs).to(self.device)
        next_states = torch.FloatTensor(np.array(next_states)).to(self.device)
        rewards = torch.FloatTensor(rewards).to(self.device)
        dones = torch.FloatTensor(dones).to(self.device)

        # 计算状态价值
        values = self.critic(states).squeeze()
        next_values = self.critic(next_states).squeeze()

        # 计算TD目标和优势函数
        with torch.no_grad():
            td_targets = rewards + self.gamma * next_values * (1 - dones)
            advantages = td_targets - values

        # 更新Critic网络
        critic_loss = F.mse_loss(values, td_targets)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # 计算新的动作分布
        dist = self.actor.get_dist(states)
        new_log_probs = dist.log_prob(actions).sum(dim=-1)
        entropy = dist.entropy().sum(dim=-1).mean()

        # 更新Actor网络
        actor_loss = -(new_log_probs * advantages.detach()).mean() - self.entropy_coef * entropy
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        return actor_loss.item(), critic_loss.item()

    def save_model(self, filepath):
        """保存模型"""
        torch.save({
            'actor_state_dict': self.actor.state_dict(),
            'critic_state_dict': self.critic.state_dict(),
            'actor_optimizer_state_dict': self.actor_optimizer.state_dict(),
            'critic_optimizer_state_dict': self.critic_optimizer.state_dict(),
        }, filepath)

    def load_model(self, filepath):
        """加载模型"""
        checkpoint = torch.load(filepath, map_location=self.device)
        self.actor.load_state_dict(checkpoint['actor_state_dict'])
        self.critic.load_state_dict(checkpoint['critic_state_dict'])
        self.actor_optimizer.load_state_dict(checkpoint['actor_optimizer_state_dict'])
        self.critic_optimizer.load_state_dict(checkpoint['critic_optimizer_state_dict'])