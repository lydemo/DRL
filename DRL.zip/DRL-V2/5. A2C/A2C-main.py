import os
import sys
import time
import argparse
import numpy as np
import gymnasium as gym
import matplotlib.pyplot as plt

# 添加项目根目录到Python搜索路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入A2C智能体和工具函数
from A2C_agent import A2CAgent
from common.tools import moving_average, compute_std


def init_parameters():
    """初始化算法参数"""
    parser = argparse.ArgumentParser(description="A2C Hyperparameters")
    parser.add_argument("--env_name", type=str, default="LunarLanderContinuous-v3", 
                       help="Environment name")
    parser.add_argument("--episodes", type=int, default=300, 
                       help="Maximum training episodes")
    parser.add_argument("--max_steps", type=int, default=1000, 
                       help="Maximum steps per episode")
    parser.add_argument("--actor_lr", type=float, default=3e-4, 
                       help="Learning rate for Actor network")
    parser.add_argument("--critic_lr", type=float, default=1e-3, 
                       help="Learning rate for Critic network")
    parser.add_argument("--gamma", type=float, default=0.99, 
                       help="Discount factor")
    parser.add_argument("--buffer_size", type=int, default=10000, 
                       help="Experience replay buffer size")
    parser.add_argument("--batch_size", type=int, default=64, 
                       help="Batch size for training")
    parser.add_argument("--entropy_coef", type=float, default=0.01, 
                       help="Entropy coefficient for exploration")
    parser.add_argument("--update_freq", type=int, default=10, 
                       help="Update frequency (episodes)")
    parser.add_argument("--save_freq", type=int, default=100, 
                       help="Model save frequency (episodes)")
    
    args = parser.parse_args()
    print("A2C Training Parameters:")
    print(f"Environment: {args.env_name}")
    print(f"Episodes: {args.episodes}")
    print(f"Actor LR: {args.actor_lr}, Critic LR: {args.critic_lr}")
    print(f"Gamma: {args.gamma}, Entropy Coef: {args.entropy_coef}")
    print(f"Buffer Size: {args.buffer_size}, Batch Size: {args.batch_size}")
    print("-" * 50)
    
    return args


def train_a2c():
    """A2C训练主函数"""
    args = init_parameters()
    
    # 创建环境
    env = gym.make(args.env_name)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    max_action = float(env.action_space.high[0])
    
    print(f"State dimension: {state_dim}")
    print(f"Action dimension: {action_dim}")
    print(f"Max action: {max_action}")
    print("-" * 50)
    
    # 创建A2C智能体
    agent = A2CAgent(
        state_dim=state_dim,
        action_dim=action_dim,
        max_action=max_action,
        actor_lr=args.actor_lr,
        critic_lr=args.critic_lr,
        gamma=args.gamma,
        buffer_size=args.buffer_size,
        batch_size=args.batch_size,
        entropy_coef=args.entropy_coef
    )
    
    # 训练记录
    episode_rewards = []
    actor_losses = []
    critic_losses = []
    best_reward = -np.inf
    
    print("开始A2C训练...")
    start_time = time.time()
    
    for episode in range(args.episodes):
        state, _ = env.reset()
        episode_reward = 0
        episode_actor_loss = 0
        episode_critic_loss = 0
        update_count = 0
        
        for step in range(args.max_steps):
            # 选择动作
            action, log_prob = agent.get_action(state)
            
            # 执行动作
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            # 存储经验
            agent.memory.store_transition(state, action, log_prob, next_state, reward, done)
            
            # 更新网络
            if len(agent.memory) >= args.batch_size and step % args.update_freq == 0:
                actor_loss, critic_loss = agent.update()
                if actor_loss is not None:
                    episode_actor_loss += actor_loss
                    episode_critic_loss += critic_loss
                    update_count += 1
            
            state = next_state
            episode_reward += reward
            
            if done:
                break
        
        # 记录训练结果
        episode_rewards.append(episode_reward)
        if update_count > 0:
            actor_losses.append(episode_actor_loss / update_count)
            critic_losses.append(episode_critic_loss / update_count)
        else:
            actor_losses.append(0)
            critic_losses.append(0)
        
        # 更新最佳奖励
        if episode_reward > best_reward:
            best_reward = episode_reward
        
        # 打印每个episode的reward
        print(f"Episode {episode + 1}/{args.episodes}, Reward: {episode_reward:.2f}")
        
        # 打印训练进度汇总
        if (episode + 1) % 50 == 0:
            avg_reward = np.mean(episode_rewards[-50:])
            print(f"Episode {episode + 1}/{args.episodes}")
            print(f"Average Reward (last 50): {avg_reward:.2f}")
            print(f"Best Reward: {best_reward:.2f}")
            print(f"Actor Loss: {actor_losses[-1]:.4f}, Critic Loss: {critic_losses[-1]:.4f}")
            print("-" * 50)
        
        # 保存模型
        if (episode + 1) % args.save_freq == 0:
            timestamp = time.strftime("%Y%m%d%H%M%S")
            model_path = os.path.join(os.path.dirname(__file__), 'models', f'a2c_model_{timestamp}.pth')
            agent.save_model(model_path)
            print(f"Model saved: {model_path}")
    
    # 训练结束
    training_time = time.time() - start_time
    print(f"\nA2C训练完成！")
    print(f"训练时间: {training_time:.2f}秒")
    print(f"最佳奖励: {best_reward:.2f}")
    
    # 保存最终模型
    timestamp = time.strftime("%Y%m%d%H%M%S")
    final_model_path = os.path.join(os.path.dirname(__file__), 'models', f'a2c_final_{timestamp}.pth')
    agent.save_model(final_model_path)
    print(f"最终模型已保存: {final_model_path}")
    
    # 绘制并保存训练曲线
    plot_training_results(episode_rewards, actor_losses, critic_losses, args.env_name)
    
    try:
        test_env = gym.make(args.env_name, render_mode="human")
    except Exception:
        test_env = gym.make(args.env_name)
    test_episodes = 3
    for episode in range(test_episodes):
        state, _ = test_env.reset()
        ep_reward = 0.0
        for _ in range(args.max_steps):
            action, _ = agent.get_action(state)
            step_ret = test_env.step(action)
            if len(step_ret) == 5:
                next_state, reward, terminated, truncated, _ = step_ret
                done = terminated or truncated
            else:
                next_state, reward, done, _ = step_ret
            ep_reward += reward
            state = next_state
            try:
                test_env.render()
            except Exception:
                pass
            if done:
                break
        print(f"Test Episode {episode+1}/{test_episodes}, Reward: {ep_reward:.2f}")
    test_env.close()

    env.close()
    return agent, episode_rewards


def plot_training_results(episode_rewards, actor_losses, critic_losses, env_name):
    timestamp = time.strftime("%Y%m%d%H%M%S")
    moving_rewards = moving_average(episode_rewards, window_size=30)
    std_rewards = compute_std(episode_rewards, window_size=30)
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(moving_rewards)), moving_rewards, color='b', label='Moving Average')
    plt.fill_between(range(len(moving_rewards)), 
                     moving_rewards - std_rewards, 
                     moving_rewards + std_rewards,
                     color='b', alpha=0.2, label='Standard Deviation')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title(f'A2C Training Rewards - {env_name}')
    plt.legend()
    plt.grid(True)
    reward_plot_dir = os.path.join(os.path.dirname(__file__), 'reward_plot')
    os.makedirs(reward_plot_dir, exist_ok=True)
    plot_path = os.path.join(reward_plot_dir, f'a2c_rewards_{timestamp}.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    print(f"训练结果图已保存: {plot_path}")
    plt.show()


if __name__ == '__main__':
    train_a2c()
