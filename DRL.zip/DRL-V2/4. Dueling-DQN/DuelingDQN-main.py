import os.path
import random
import gymnasium as gym
import numpy as np
import argparse
import matplotlib.pyplot as plt
import time
import torch

import importlib

dueling_agent = importlib.import_module('DuelingDQN-agent')
Agent = dueling_agent.Agent


def save_model(path, model_state_dict, model_name):
    """
    Save the model state dictionary to a file.
    """
    if not os.path.exists(os.path.join(path, 'models')):
        os.makedirs(os.path.join(path, 'models'))
    
    timestamp = time.strftime("%Y%m%d%H%M%S", time.localtime())
    model_path = os.path.join(path, 'models', f'{model_name}_{timestamp}.pth')
    torch.save(model_state_dict, model_path)
    print(f"Model saved to {model_path}")


def moving_average(data, window_size):
    """
    Calculate the moving average of the data.
    """
    if len(data) < window_size:
        return data
    
    moving_avg = []
    for i in range(len(data)):
        if i < window_size - 1:
            moving_avg.append(np.mean(data[:i+1]))
        else:
            moving_avg.append(np.mean(data[i-window_size+1:i+1]))
    
    return moving_avg


def compute_std(data, window_size):
    """
    Calculate the standard deviation of the data.
    """
    if len(data) < window_size:
        return [0] * len(data)
    
    std_values = []
    for i in range(len(data)):
        if i < window_size - 1:
            std_values.append(np.std(data[:i+1]))
        else:
            std_values.append(np.std(data[i-window_size+1:i+1]))
    
    return std_values


def plot_reward(reward_list, window_size=30):
    """
    Plot the reward curve with moving average and standard deviation.
    """
    # Create reward_plot directory if it doesn't exist
    plot_dir = 'reward_plot'
    if not os.path.exists(plot_dir):
        os.makedirs(plot_dir)
    
    # Calculate moving average and standard deviation
    ma_rewards = moving_average(reward_list, window_size)
    std_rewards = compute_std(reward_list, window_size)
    
    # Create the plot
    plt.figure(figsize=(12, 6))
    
    episodes = range(1, len(reward_list) + 1)
    
    # Plot moving average
    plt.plot(episodes, ma_rewards, 'b-', linewidth=2, label=f'Moving Average (window={window_size})')
    
    # Plot standard deviation as shaded area
    ma_rewards = np.array(ma_rewards)
    std_rewards = np.array(std_rewards)
    plt.fill_between(episodes, ma_rewards - std_rewards, ma_rewards + std_rewards, 
                     alpha=0.3, color='blue', label='Standard Deviation')
    
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title('Dueling-DQN Training Reward Curve')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Save the plot
    timestamp = time.strftime("%Y%m%d%H%M%S", time.localtime())
    plot_path = os.path.join(plot_dir, f'dueling_dqn_rewards_{timestamp}.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    # Save reward data to text file
    data_path = os.path.join(plot_dir, f'dueling_dqn_reward_data_{timestamp}.txt')
    with open(data_path, 'w') as f:
        f.write("Episode,Reward,Moving_Average,Std_Dev\n")
        for i, (reward, ma, std) in enumerate(zip(reward_list, ma_rewards, std_rewards)):
            f.write(f"{i+1},{reward},{ma},{std}\n")
    
    print(f"Reward curve saved to {plot_path}")
    print(f"Reward data saved to {data_path}")


def init_parameters():
    """
    Initialize the parameters required for the algorithm.
    """
    parser = argparse.ArgumentParser(description="Dueling-DQN Hyperparameters")
    parser.add_argument("--env_name", type=str, default="CliffWalking-v1", help="Environment name")
    parser.add_argument("--episode_length", type=int, default=500, help="Maximum episodes")
    parser.add_argument("--step_length", type=int, default=100, help="Maximum steps per episode")
    parser.add_argument("--epsilon_start", type=float, default=1,
                        help="Initial value of epsilon in epsilon-greedy exploration")
    parser.add_argument("--epsilon_end", type=float, default=0.02,
                        help="Final value of epsilon in epsilon-greedy exploration")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate for training the Q-network")
    parser.add_argument("--buffer_size", type=int, default=10000, help="The size of replay buffer")
    parser.add_argument("--batch_size", type=int, default=128, help="Batch size for training")
    parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor for rewards")
    parser.add_argument("--interval", type=int, default=100, help="Training interval of the target Q-network")

    arg = parser.parse_args()
    print(arg)
    return arg


if __name__ == '__main__':
    args = init_parameters()
    try:
        env = gym.make(args.env_name)
    except Exception:
        fallback = args.env_name.replace('-v1', '-v0') if args.env_name.endswith('-v1') else 'CliffWalking-v0'
        env = gym.make(fallback)
    
    # Handle different observation space types
    if hasattr(env.observation_space, 'shape') and len(env.observation_space.shape) > 0:
        state_dim = env.observation_space.shape[0]
    else:
        # For discrete observation spaces like CliffWalking-v0
        state_dim = env.observation_space.n
    
    action_dim = env.action_space.n

    agent = Agent(state_dim, action_dim, args.lr, args.buffer_size, args.batch_size, args.gamma, args.interval)

    reward_list = []
    for episode_i in range(args.episode_length):
        # Handle different gym versions - some return tuple, some return just state
        reset_result = env.reset()
        if isinstance(reset_result, tuple):
            state, info = reset_result
        else:
            state = reset_result
            info = {}
        episode_reward = 0

        for step_i in range(args.step_length):
            # epsilon greedy
            epsilon = np.interp(x=episode_i*args.step_length+step_i, xp=[0, args.episode_length*args.step_length/2],
                                fp=[args.epsilon_start, args.epsilon_end])
            random_sample = random.random()
            if random_sample <= epsilon:
                action = env.action_space.sample()
            else:
                action = agent.get_action(state)

            # Handle different gym versions - some return 4 values, some return 5
            step_result = env.step(action)
            if len(step_result) == 4:
                next_state, reward, done, info_ = step_result
                terminated = done
                truncated = False
            else:
                next_state, reward, terminated, truncated, info_ = step_result
            
            agent.memory.store_transition(state, action, next_state, reward, terminated or truncated)
            agent.update()

            state = next_state
            episode_reward += reward
            if terminated or truncated:
                break

        print(f"Episode: {episode_i+1}, Reward: {round(episode_reward, 3)}")
        reward_list.append(episode_reward)

    # save model
    save_model(os.path.dirname(os.path.realpath(__file__)), agent.q_net.state_dict(), 'dueling_dqn_q')
    # plot reward curve
    plot_reward(reward_list, 30)

    try:
        test_env = gym.make(args.env_name, render_mode="human")
    except Exception:
        test_env = gym.make(args.env_name)
    test_episodes = 3
    for episode_i in range(test_episodes):
        reset_ret = test_env.reset()
        if isinstance(reset_ret, tuple):
            state_raw, _ = reset_ret
        else:
            state_raw = reset_ret
        ep_reward = 0.0
        for _ in range(args.step_length):
            action = agent.get_action(state_raw)
            step_ret = test_env.step(action)
            if len(step_ret) == 5:
                next_state_raw, reward, terminated, truncated, _ = step_ret
                done = terminated or truncated
            else:
                next_state_raw, reward, done, _ = step_ret
            ep_reward += reward
            state_raw = next_state_raw
            try:
                test_env.render()
            except Exception:
                pass
            if done:
                break
        print(f"Test Episode {episode_i+1}/{test_episodes}, Reward: {round(ep_reward, 3)}")
    test_env.close()
