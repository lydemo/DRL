#### Readers can ignore this directory.

#### This directory contains a shared utility package for all algorithms, including plotting and other code unrelated to algorithm implementation.