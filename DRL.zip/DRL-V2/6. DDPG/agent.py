import torch
import random
import numpy as np
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from collections import deque


class Actor(nn.Module):
    def __init__(self, state_shape, action_dim):
        super(Actor, self).__init__()
        self.action_dim = action_dim
        self.is_image = (len(state_shape) == 3)
        if self.is_image:
            c = state_shape[2]
            # CNN feature extractor (channels-first)
            self.conv1 = nn.Conv2d(c, 32, kernel_size=8, stride=4)
            self.conv2 = nn.Conv2d(32, 64, kernel_size=4, stride=2)
            self.conv3 = nn.Conv2d(64, 64, kernel_size=3, stride=1)
            # compute conv output size dynamically
            self.conv_out_dim = self._get_conv_output((c, state_shape[0], state_shape[1]))
            self.fc1 = nn.Linear(self.conv_out_dim, 512)
            self.fc2 = nn.Linear(512, action_dim)
        else:
            # MLP for vector observations
            input_dim = int(np.prod(state_shape))
            self.mlp = nn.Sequential(
                nn.Linear(input_dim, 256),
                nn.ReLU(),
                nn.Linear(256, 256),
                nn.ReLU(),
                nn.Linear(256, action_dim),
            )

    def _get_conv_output(self, shape_chw):
        with torch.no_grad():
            x = torch.rand(1, *shape_chw)
            x = self.conv1(x)
            x = self.conv2(x)
            x = self.conv3(x)
            return int(np.prod(x.size()))

    def forward(self, state):
        if self.is_image:
            # state: (B, C, H, W), normalized to [0,1]
            x = F.relu(self.conv1(state))
            x = F.relu(self.conv2(x))
            x = F.relu(self.conv3(x))
            x = torch.flatten(x, 1)
            x = F.relu(self.fc1(x))
            a = self.fc2(x)
            # CarRacing mapping: steer [-1,1], gas/brake [0,1]
            if self.action_dim == 3:
                steer = torch.tanh(a[..., 0:1])
                gas = torch.sigmoid(a[..., 1:2])
                brake = torch.sigmoid(a[..., 2:3])
                return torch.cat([steer, gas, brake], dim=-1)
            else:
                return torch.tanh(a)
        else:
            # state: (B, D) vector
            a = self.mlp(state)
            # LunarLanderContinuous expects [-1,1] per action
            return torch.tanh(a)


class Critic(nn.Module):
    def __init__(self, state_shape, action_dim):
        super(Critic, self).__init__()
        self.action_dim = action_dim
        self.is_image = (len(state_shape) == 3)
        if self.is_image:
            c = state_shape[2]
            self.conv1 = nn.Conv2d(c, 32, kernel_size=8, stride=4)
            self.conv2 = nn.Conv2d(32, 64, kernel_size=4, stride=2)
            self.conv3 = nn.Conv2d(64, 64, kernel_size=3, stride=1)
            self.conv_out_dim = self._get_conv_output((c, state_shape[0], state_shape[1]))
            # combine conv features with action
            self.fc1 = nn.Linear(self.conv_out_dim + action_dim, 512)
            self.fc2 = nn.Linear(512, 1)
        else:
            # MLP for vector observations + action
            input_dim = int(np.prod(state_shape)) + action_dim
            self.mlp = nn.Sequential(
                nn.Linear(input_dim, 256),
                nn.ReLU(),
                nn.Linear(256, 256),
                nn.ReLU(),
                nn.Linear(256, 1),
            )

    def _get_conv_output(self, shape_chw):
        with torch.no_grad():
            x = torch.rand(1, *shape_chw)
            x = self.conv1(x)
            x = self.conv2(x)
            x = self.conv3(x)
            return int(np.prod(x.size()))

    def forward(self, state, action):
        if self.is_image:
            # state: (B, C, H, W), action: (B, action_dim)
            x = F.relu(self.conv1(state))
            x = F.relu(self.conv2(x))
            x = F.relu(self.conv3(x))
            x = torch.flatten(x, 1)
            x = torch.cat([x, action], dim=1)
            x = F.relu(self.fc1(x))
            q = self.fc2(x)
            return q
        else:
            # state: (B, D), action: (B, action_dim)
            x = torch.cat([state, action], dim=1)
            q = self.mlp(x)
            return q


class Memory:
    def __init__(self, capacity):
        self.memory = deque([], maxlen=capacity)

    def __len__(self):
        return len(self.memory)

    def store_transition(self, state, action, next_state, reward, end):
        self.memory.append((state, action, next_state, reward, end))

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)


class Agent:
    def __init__(self, state_shape, action_dim, actor_lr, critic_lr, buffer_size, batch_size, gamma, update_interval, tau, device=None, max_grad_norm=None, action_low=None, action_high=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.actor = Actor(state_shape, action_dim).to(self.device)
        self.target_actor = Actor(state_shape, action_dim).to(self.device)
        self.target_actor.load_state_dict(self.actor.state_dict())
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=actor_lr)

        self.critic = Critic(state_shape, action_dim).to(self.device)
        self.target_critic = Critic(state_shape, action_dim).to(self.device)
        self.target_critic.load_state_dict(self.critic.state_dict())
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=critic_lr)

        self.memory = Memory(buffer_size)

        self.batch_size = batch_size
        self.gamma = gamma
        self.update_interval = update_interval
        self.tau = tau
        self._update_step = 0
        self.max_grad_norm = max_grad_norm
        # 动作边界用于噪声裁剪
        self.action_low = None if action_low is None else np.array(action_low, dtype=np.float32)
        self.action_high = None if action_high is None else np.array(action_high, dtype=np.float32)

    def _to_tensor(self, states):
        # 支持图像 (B,H,W,C)/(H,W,C) 与向量 (B,D)/(D)
        if isinstance(states, np.ndarray):
            if states.ndim == 3:  # single image (H,W,C)
                states = states[None, ...]
            if states.ndim == 4:  # batch images (B,H,W,C)
                t = torch.from_numpy(states).float().permute(0, 3, 1, 2)
                # 仅在像素图像时归一化
                if states.dtype in (np.uint8, np.int8, np.int16):
                    t = t / 255.0
                return t.to(self.device)
            elif states.ndim == 2:  # batch vectors (B,D)
                t = torch.from_numpy(states).float()
                return t.to(self.device)
            elif states.ndim == 1:  # single vector (D)
                t = torch.from_numpy(states).float().unsqueeze(0)
                return t.to(self.device)
        if torch.is_tensor(states):
            return states.to(self.device)
        raise ValueError("Unsupported state format for _to_tensor")

    def get_action(self, state, noise_std=None):
        state_t = self._to_tensor(state)
        action = self.actor(state_t).detach().cpu().numpy()[0]
        if noise_std is not None and noise_std > 0:
            noise = np.random.normal(0.0, noise_std, size=action.shape).astype(np.float32)
            action = action + noise
            # 按边界裁剪（优先使用环境边界）
            if self.action_low is not None and self.action_high is not None:
                action = np.clip(action, self.action_low, self.action_high)
            else:
                # 回退：CarRacing 三维或通用 [-1,1]
                if action.shape[0] == 3:
                    action[0] = float(np.clip(action[0], -1.0, 1.0))
                    action[1] = float(np.clip(action[1], 0.0, 1.0))
                    action[2] = float(np.clip(action[2], 0.0, 1.0))
                else:
                    action = np.clip(action, -1.0, 1.0)
        return action

    def update(self):
        if len(self.memory) < self.batch_size:
            return

        states, actions, next_states, rewards, ends = zip(*self.memory.sample(self.batch_size))
        states_np = np.array(states, dtype=object)
        next_states_np = np.array(next_states, dtype=object)
        # 安全拼接为 numpy 批次
        try:
            states_np = np.stack(states)
            next_states_np = np.stack(next_states)
        except Exception:
            states_np = np.array(states)
            next_states_np = np.array(next_states)
        states_t = self._to_tensor(states_np)
        next_states_t = self._to_tensor(next_states_np)
        actions_t = torch.FloatTensor(np.vstack(actions)).to(self.device)
        rewards_t = torch.FloatTensor(rewards).unsqueeze(1).to(self.device)
        ends_t = torch.FloatTensor(ends).unsqueeze(1).to(self.device)

        # update critic network
        with torch.no_grad():
            next_action = self.target_actor(next_states_t)
            target_Q = self.target_critic(next_states_t, next_action)
            target_Q = rewards_t + self.gamma * target_Q * (1 - ends_t)
        Q = self.critic(states_t, actions_t)
        critic_loss = nn.MSELoss()(Q, target_Q)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        if self.max_grad_norm is not None:
            nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
        self.critic_optimizer.step()

        # update actor network
        actor_actions = self.actor(states_t)
        actor_loss = -self.critic(states_t, actor_actions).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        if self.max_grad_norm is not None:
            nn.utils.clip_grad_norm_(self.actor.parameters(), self.max_grad_norm)
        self.actor_optimizer.step()

        # soft update target networks (periodic by update_interval)
        self._update_step += 1
        if self._update_step % self.update_interval == 0:
            for target_param, param in zip(self.target_critic.parameters(), self.critic.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
            for target_param, param in zip(self.target_actor.parameters(), self.actor.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
