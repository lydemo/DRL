import os.path
import gymnasium as gym
import numpy as np
import random
import argparse
import time
import matplotlib.pyplot as plt

import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), ".."))
from agent import Agent
from common.tools import plot_reward, save_model, moving_average, compute_std


def make_env(env_name, render=False, render_mode='human'):
    try:
        import gymnasium as gymn
        return gymn.make(env_name, render_mode=render_mode) if render else gymn.make(env_name)
    except Exception:
        import gym as gym_old
        version_map = {
            'LunarLanderContinuous-v3': 'LunarLanderContinuous-v2',
            'LunarLander-v3': 'LunarLander-v2',
            'CarRacing-v3': 'CarRacing-v2',
        }
        fallback = version_map.get(env_name, env_name)
        try:
            return gym_old.make(fallback, render_mode=render_mode) if render else gym_old.make(fallback)
        except Exception:
            second_map = {
                'LunarLanderContinuous-v3': 'LunarLanderContinuous-v0',
                'LunarLanderContinuous-v2': 'LunarLanderContinuous-v0',
                'LunarLander-v3': 'LunarLander-v0',
                'LunarLander-v2': 'LunarLander-v0',
                'CarRacing-v3': 'CarRacing-v0',
                'CarRacing-v2': 'CarRacing-v0',
            }
            second = second_map.get(env_name, second_map.get(fallback, fallback))
            return gym_old.make(second, render_mode=render_mode) if render else gym_old.make(second)


def init_parameters():
    """
    Initialize the parameters required for the algorithm.
    """
    parser = argparse.ArgumentParser(description="DDPG Hyperparameters")
    parser.add_argument("--env_name", type=str, default="LunarLanderContinuous-v3", help="Environment name")
    parser.add_argument("--episode_length", type=int, default=300, help="Maximum episodes")
    parser.add_argument("--step_length", type=int, default=1000, help="Maximum steps per episode")
    parser.add_argument("--epsilon_start", type=float, default=1, help="Initial value of epsilon in epsilon-greedy exploration")
    parser.add_argument("--epsilon_end", type=float, default=0.02, help="Final value of epsilon in epsilon-greedy exploration")
    parser.add_argument("--actor_lr", type=float, default=1e-4, help="Learning rate for actor network")
    parser.add_argument("--critic_lr", type=float, default=1e-3, help="Learning rate for critic network")
    parser.add_argument("--buffer_size", type=int, default=100000, help="Size of the replay buffer")
    parser.add_argument("--batch_size", type=int, default=128, help="Batch size for training")
    parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor for rewards")
    parser.add_argument("--interval", type=int, default=100, help="Training interval of the target network")
    parser.add_argument("--tau", type=float, default=0.01, help="Soft update parameter for target network")
    parser.add_argument("--noise_start", type=float, default=0.3, help="Initial Gaussian noise std for policy actions")
    parser.add_argument("--noise_end", type=float, default=0.05, help="Final Gaussian noise std for policy actions")
    parser.add_argument("--warmup_steps", type=int, default=3000, help="Steps to collect with random actions before updates")
    parser.add_argument("--max_grad_norm", type=float, default=1.0, help="Gradient clipping norm for actor/critic")
    arg = parser.parse_args()
    print(arg)
    return arg


if __name__ == '__main__':
    args = init_parameters()
    environment = make_env(args.env_name)
    # 通用获取观测与动作维度
    state_shape = environment.observation_space.shape
    action_dim = environment.action_space.shape[0]
    # 动作边界（用于噪声裁剪）
    action_low = getattr(environment.action_space, 'low', None)
    action_high = getattr(environment.action_space, 'high', None)
    agent = Agent(state_shape, action_dim, args.actor_lr, args.critic_lr, args.buffer_size, args.batch_size, args.gamma, args.interval, args.tau, max_grad_norm=args.max_grad_norm, action_low=action_low, action_high=action_high)

    reward_list = []
    for episode_i in range(args.episode_length):
        # reset 兼容
        try:
            state, info = environment.reset()
        except Exception:
            state = environment.reset()
            info = {}
        episode_reward = 0

        for step_i in range(args.step_length):
            # smooth exploration with Gaussian noise + warmup
            global_step = episode_i * args.step_length + step_i
            total_steps = args.episode_length * args.step_length
            noise_std = float(np.interp(global_step, [0, total_steps / 2], [args.noise_start, args.noise_end]))
            if global_step < args.warmup_steps:
                # 通用暖启动：直接采样动作空间
                action = environment.action_space.sample()
                action = np.array(action, dtype=np.float32)
            else:
                action = agent.get_action(state, noise_std=noise_std)
                action = np.array(action, dtype=np.float32)

            # step 兼容
            try:
                next_state, reward, terminated, truncated, info = environment.step(action)
                done = terminated or truncated
            except Exception:
                next_state, reward, done, info = environment.step(action)
            agent.memory.store_transition(state, action, next_state, reward, done)
            if global_step >= args.warmup_steps:
                agent.update()

            state = next_state
            episode_reward += reward
            if done:
                break

        reward_list.append(episode_reward)
        print(f"Episode: {episode_i+1}, Reward: {round(episode_reward, 3)}")

    # save model
    save_model(os.path.dirname(os.path.realpath(__file__)), agent.actor.state_dict(), 'ddpg_actor')

    # 保存奖励曲线到 reward_plot 文件夹
    reward_plot_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'reward_plot')
    os.makedirs(reward_plot_dir, exist_ok=True)
    timestamp = time.strftime("%Y%m%d%H%M%S")

    moving_reward_list = moving_average(reward_list, 30)
    std_reward_list = compute_std(reward_list, 30)

    plt.figure(figsize=(10, 6))
    plt.plot(range(len(moving_reward_list)), moving_reward_list, color='b', label='Moving Average')
    plt.fill_between(range(len(moving_reward_list)),
                     moving_reward_list - std_reward_list,
                     moving_reward_list + std_reward_list,
                     color='b', alpha=0.2, label='Standard Deviation')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title(f'DDPG Training Rewards - {args.env_name}')
    plt.legend()
    plt.grid(True)

    plt.savefig(os.path.join(reward_plot_dir, f'ddpg_rewards_{timestamp}.png'), dpi=300, bbox_inches='tight')
    plt.show()

    test_env = make_env(args.env_name, render=True, render_mode="human")
    test_episodes = 3
    for episode_i in range(test_episodes):
        try:
            state, _ = test_env.reset()
        except Exception:
            state = test_env.reset()
        ep_reward = 0.0
        for _ in range(args.step_length):
            action = agent.get_action(state)
            try:
                step_ret = test_env.step(action)
                next_state, reward, terminated, truncated, _ = step_ret
                done = terminated or truncated
            except Exception:
                next_state, reward, done, _ = test_env.step(action)
            ep_reward += reward
            state = next_state
            try:
                test_env.render()
            except Exception:
                pass
            if done:
                break
        print(f"Test Episode {episode_i+1}/{test_episodes}, Reward: {round(ep_reward, 3)}")
    test_env.close()
