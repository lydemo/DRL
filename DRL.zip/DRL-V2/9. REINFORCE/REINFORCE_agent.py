import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal
import numpy as np

import torch.nn.functional as F

class Policy(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Policy, self).__init__()
        self.fc1 = nn.Linear(state_dim, 128)
        self.fc_mu = nn.Linear(128, action_dim)
        self.fc_std = nn.Linear(128, action_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        mu = torch.tanh(self.fc_mu(x)) * 2 # Action range [-2, 2]
        std = F.softplus(self.fc_std(x)) + 1e-3 # Avoid std=0
        return mu, std

class REINFORCEAgent:
    def __init__(self, state_dim, action_dim, lr=1e-4, gamma=0.99):
        self.policy = Policy(state_dim, action_dim)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=lr)
        self.gamma = gamma
        self.saved_log_probs = []
        self.rewards = []
        
        # 用于存储多个轨迹的蒙特卡洛采样
        self.trajectory_log_probs = []  # 存储多个轨迹的log_probs
        self.trajectory_rewards = []    # 存储多个轨迹的rewards

    def select_action(self, state):
        state = torch.from_numpy(state).float().unsqueeze(0)
        mu, std = self.policy(state)
        m = Normal(mu, std)
        action = m.sample()
        self.saved_log_probs.append(m.log_prob(action))
        return action.clamp(-1.0, 1.0).numpy()[0]

    def store_trajectory(self):
        """
        存储当前轨迹到蒙特卡洛采样缓冲区
        """
        if len(self.saved_log_probs) > 0 and len(self.rewards) > 0:
            self.trajectory_log_probs.append(self.saved_log_probs.copy())
            self.trajectory_rewards.append(self.rewards.copy())
        
        # 清空当前轨迹
        del self.rewards[:]
        del self.saved_log_probs[:]

    def update_policy_monte_carlo(self, num_trajectories=None):
        """
        使用蒙特卡洛采样更新策略
        明确实现策略梯度定理中的期望近似: E_π[∇θ log π(a|s) * G_t] ≈ (1/N) * Σᵢ [∇θ log π(aᵢ|sᵢ) * G_tᵢ]
        """
        if len(self.trajectory_log_probs) == 0:
            return
        
        all_log_probs = []
        all_returns = []
        
        # 处理每条轨迹 (蒙特卡洛采样的每个样本)
        for traj_idx, (log_probs, rewards) in enumerate(zip(self.trajectory_log_probs, self.trajectory_rewards)):
            # 计算该轨迹的折扣回报
            R = 0
            returns = []
            for r in rewards[::-1]:
                R = r + self.gamma * R
                returns.insert(0, R)
            
            # 收集所有轨迹的数据
            all_log_probs.extend(log_probs)
            all_returns.extend(returns)
        
        # 标准化所有轨迹的回报 (作为基线减少方差)
        all_returns = torch.tensor(all_returns)
        all_returns = (all_returns - all_returns.mean()) / (all_returns.std() + 1e-9)
        
        # 计算策略梯度的蒙特卡洛估计
        # 这里就是 E_π[∇θ log π(a|s) * G_t] 的蒙特卡洛近似
        policy_loss = []
        for log_prob, G_t in zip(all_log_probs, all_returns):
            # 每一项都是 ∇θ log π(aᵢ|sᵢ) * G_tᵢ 的一个样本
            policy_loss.append(-log_prob * G_t)
        
        # 执行梯度更新
        self.optimizer.zero_grad()
        total_loss = torch.cat(policy_loss).sum()
        total_loss.backward()
        self.optimizer.step()
        
        # 清空轨迹缓冲区
        self.trajectory_log_probs.clear()
        self.trajectory_rewards.clear()

    def update_policy(self):
        """
        保留原有的单轨迹更新方法 (向后兼容)
        """
        R = 0
        policy_loss = []
        returns = []
        for r in self.rewards[::-1]:
            R = r + self.gamma * R
            returns.insert(0, R)
        
        returns = torch.tensor(returns)
        returns = (returns - returns.mean()) / (returns.std() + 1e-9)

        for log_prob, R in zip(self.saved_log_probs, returns):
            policy_loss.append(-log_prob * R)

        self.optimizer.zero_grad()
        policy_loss = torch.cat(policy_loss).sum()
        policy_loss.backward()
        self.optimizer.step()

        del self.rewards[:]
        del self.saved_log_probs[:]

    def save_model(self, path):
        torch.save(self.policy.state_dict(), path)

    def load_model(self, path):
        self.policy.load_state_dict(torch.load(path))