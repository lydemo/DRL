# REINFORCE

This folder contains an implementation of the REINFORCE algorithm for the CartPole-v1 environment.

## Files

- `REINFORCE_agent.py`: Contains the REINFORCE agent class, including the policy network and the update rule.
- `REINFORCE-main.py`: The main script to train the REINFORCE agent.
- `REINFORCE-test.py`: The script to test a trained REINFORCE agent.
- `models/`: Directory to save trained models.
- `reward_plot/`: Directory to save reward plots.

## How to Run

### Training

To train the agent, run the following command:

```bash
python REINFORCE-main.py
```

This will train the agent for 1000 episodes and save the trained model in the `models` directory. It will also save a plot of the rewards per episode in the `reward_plot` directory.

### Testing

To test a trained agent, run the following command:

```bash
python REINFORCE-test.py --episodes 10
```

This will load the latest saved model from the `models` directory and run it for 10 episodes. You can also specify a model to test with the `--model_path` argument:

```bash
python REINFORCE-test.py --episodes 10 --model_path models/reinforce_policy_xxxxxxxxxxxxxx.pth
```