import gymnasium as gym
import torch
import numpy as np
import matplotlib.pyplot as plt
from REINFORCE_agent import REINFORCEAgent
import os
import datetime
import sys

# Add the project root directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common.tools import moving_average, compute_std


def plot_training_results(reward_list, env_name):
    window_size = 30
    moving_rewards = moving_average(reward_list, window_size)
    std_rewards = compute_std(reward_list, window_size)
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(moving_rewards)), moving_rewards, color='b', label='Moving Average')
    plt.fill_between(range(len(moving_rewards)),
                     np.array(moving_rewards) - np.array(std_rewards),
                     np.array(moving_rewards) + np.array(std_rewards),
                     color='b', alpha=0.2, label='Standard Deviation')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title(f'REINFORCE Training Rewards - {env_name}')
    plt.legend()
    plt.grid(True)
    reward_plot_dir = os.path.join(os.path.dirname(__file__), 'reward_plot')
    os.makedirs(reward_plot_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    plot_path = os.path.join(reward_plot_dir, f'reinforce_rewards_{timestamp}.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    print(f"Plot saved to {plot_path}")
    plt.show()


def explain_monte_carlo_sampling():
    """
    解释蒙特卡洛采样在REINFORCE中的应用
    """
    print("\n" + "="*80)
    print("蒙特卡洛采样在REINFORCE算法中的应用说明")
    print("="*80)
    print("策略梯度定理: ∇θ J(θ) = E_π[∇θ log π(a|s) * G_t]")
    print()
    print("其中:")
    print("  - E_π[...] 是在策略π下的期望")
    print("  - ∇θ log π(a|s) 是策略的对数梯度")
    print("  - G_t 是从时间步t开始的折扣回报")
    print()
    print("蒙特卡洛近似:")
    print("  E_π[∇θ log π(a|s) * G_t] ≈ (1/N) * Σᵢ [∇θ log π(aᵢ|sᵢ) * G_tᵢ]")
    print()
    print("实现步骤:")
    print("  1. 从当前策略π采样N条轨迹 (蒙特卡洛采样)")
    print("  2. 计算每条轨迹中每个状态-动作对的折扣回报G_t")
    print("  3. 计算每个状态-动作对的策略梯度 ∇θ log π(a|s)")
    print("  4. 将所有样本的梯度求平均作为期望的近似")
    print("  5. 使用这个近似梯度更新策略参数")
    print("="*80)
    print()


def main():
    env_name = 'LunarLanderContinuous-v3'
    env = gym.make(env_name)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    agent = REINFORCEAgent(state_dim, action_dim)

    episodes = 500
    print_interval = 1  # 每个episode都打印
    scores = []
    
    # 蒙特卡洛采样参数
    trajectories_per_update = 5  # 每次收集5条轨迹后进行一次策略更新
    trajectory_count = 0
    
    print(f"开始训练 - 使用蒙特卡洛采样")
    print("=" * 50)

    for i_episode in range(1, episodes + 1):
        state, _ = env.reset()
        ep_reward = 0
        
        # 执行一个完整的episode (采样一条轨迹)
        for t in range(1, 10000):
            action = agent.select_action(state)
            state, reward, done, _, _ = env.step(action)
            agent.rewards.append(reward)
            ep_reward += reward
            if done:
                break
        
        scores.append(ep_reward)
        
        # 存储当前轨迹到蒙特卡洛采样缓冲区
        agent.store_trajectory()
        trajectory_count += 1
        
        # 当收集到足够的轨迹时，使用蒙特卡洛采样更新策略
        if trajectory_count >= trajectories_per_update:
            agent.update_policy_monte_carlo()
            trajectory_count = 0  # 重置计数器

        # 每个episode都打印reward
        print(f'Episode {i_episode}\tReward: {ep_reward:.2f}')
    
    # 如果还有剩余的轨迹，进行最后一次更新
    if trajectory_count > 0:
        agent.update_policy_monte_carlo()

    # Save model
    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    model_path = os.path.join("models", f"reinforce_policy_mc_{timestamp}.pth")
    agent.save_model(model_path)
    print(f"Model saved to {model_path}")

    # Plot the results
    plot_training_results(scores, env_name)

    try:
        test_env = gym.make(env_name, render_mode="human")
    except Exception:
        test_env = gym.make(env_name)
    test_episodes = 3
    for i in range(test_episodes):
        state, _ = test_env.reset()
        ep_reward = 0.0
        for _ in range(10000):
            action = agent.select_action(state)
            step_ret = test_env.step(action)
            if len(step_ret) == 5:
                state, reward, terminated, truncated, _ = step_ret
                done = terminated or truncated
            else:
                state, reward, done, _ = step_ret
            ep_reward += reward
            try:
                test_env.render()
            except Exception:
                pass
            if done:
                break
        print(f"Test Episode {i+1}/{test_episodes}, Reward: {ep_reward:.2f}")
    test_env.close()


if __name__ == '__main__':
    main()
