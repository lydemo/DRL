import os.path
import random
import gymnasium as gym
import numpy as np
import argparse
import importlib.util
import sys
import time
import torch
import matplotlib.pyplot as plt

# 添加项目根目录到Python搜索路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import Agent from DDQN-agent.py
spec = importlib.util.spec_from_file_location("ddqn_agent", "DDQN-agent.py")
ddqn_agent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ddqn_agent)
Agent = ddqn_agent.Agent

# 直接实现save_model函数以避免导入common.tools
def save_model(current_path, model, model_name):
    """
    Save the trained model
    """
    model_path = current_path + '/models/'
    if not os.path.exists(model_path):
        os.makedirs(model_path)
    timestamp = time.strftime("%Y%m%d%H%M%S")
    torch.save(model, model_path + f"{model_name}_{timestamp}.pth")


def moving_average(data, window_size=30):
    """
    Smooth the data using a sliding window
    """
    averaged_data = []
    for i in range(len(data)):
        start_idx = max(0, i - window_size + 1)
        window_data = data[start_idx:i + 1]
        avg = np.mean(window_data)
        averaged_data.append(avg)
    return np.array(averaged_data)


def compute_std(data, window_size=30):
    """
    Calculate the sliding window standard deviation
    """
    stds = []
    for i in range(len(data)):
        start_idx = max(0, i - window_size + 1)
        window_data = data[start_idx:i + 1]
        std_value = np.std(window_data)
        stds.append(std_value)
    return np.array(stds)


def plot_reward(reward_list, window_size=30, env_name=None):
    """
    Plot the reward curve and save to reward_plot folder (SARSA style)
    """
    # Create reward_plot directory if it doesn't exist
    current_path = os.path.dirname(os.path.realpath(__file__))
    plot_path = os.path.join(current_path, 'reward_plot')
    if not os.path.exists(plot_path):
        os.makedirs(plot_path)
    
    # Calculate moving average and standard deviation
    moving_reward_list = moving_average(reward_list, window_size)
    std_reward_list = compute_std(reward_list, window_size)
    
    # Create the plot (SARSA style)
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(moving_reward_list)), moving_reward_list, color='b', label='Moving Average')
    plt.fill_between(range(len(moving_reward_list)), 
                     moving_reward_list - std_reward_list, 
                     moving_reward_list + std_reward_list,
                     color='b', alpha=0.2, label='Standard Deviation')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title(f'Double-DQN Training Rewards - {env_name}' if env_name else 'Double-DQN Training Rewards')
    plt.legend()
    plt.grid(True)
    
    # Save the plot
    timestamp = time.strftime("%Y%m%d%H%M%S")
    plot_filename = os.path.join(plot_path, f'ddqn_rewards_{timestamp}.png')
    plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
    print(f"Reward curve saved to: {plot_filename}")
    
    # Also save the data
    data_filename = os.path.join(plot_path, f'ddqn_reward_data_{timestamp}.txt')
    with open(data_filename, 'w') as f:
        f.write("Episode,Reward,MovingAverage,StdDev\n")
        for i, (reward, moving_avg, std_dev) in enumerate(zip(reward_list, moving_reward_list, std_reward_list)):
            f.write(f"{i+1},{reward},{moving_avg},{std_dev}\n")
    print(f"Reward data saved to: {data_filename}")
    
    plt.show()


def init_parameters():
    """
    Initialize the parameters required for the algorithm.
    """
    parser = argparse.ArgumentParser(description="Double-DQN Hyperparameters")
    parser.add_argument("--env_name", type=str, default="CliffWalking-v1", help="Environment name")
    parser.add_argument("--episode_length", type=int, default=200, help="Maximum episodes")
    parser.add_argument("--step_length", type=int, default=100, help="Maximum steps per episode")
    parser.add_argument("--epsilon_start", type=float, default=1, help="Initial value of epsilon in epsilon-greedy exploration")
    parser.add_argument("--epsilon_end", type=float, default=0.02, help="Final value of epsilon in epsilon-greedy exploration")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate for training the Q-network")
    parser.add_argument("--buffer_size", type=int, default=10000, help="The size of replay buffer")
    parser.add_argument("--batch_size", type=int, default=128, help="Batch size for training")
    parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor for rewards")
    parser.add_argument("--interval", type=int, default=100, help="Training interval of the target Q-network")
    arg = parser.parse_args()
    print(arg)
    return arg


if __name__ == '__main__':
    args = init_parameters()
    try:
        env = gym.make(args.env_name)
    except Exception:
        fallback = args.env_name.replace('-v1', '-v0') if args.env_name.endswith('-v1') else args.env_name
        env = gym.make(fallback)
        print(f"Using fallback environment: {fallback}")
    state_dim = env.observation_space.n  # CliffWalking has discrete state space
    action_dim = env.action_space.n

    agent = Agent(state_dim, action_dim, args.lr, args.buffer_size, args.batch_size, args.gamma, args.interval)

    reward_list = []
    for episode_i in range(args.episode_length):
        state_raw, info = env.reset()
        state = state_raw
        episode_reward = 0

        for step_i in range(args.step_length):
            # epsilon greedy
            epsilon = np.interp(x=episode_i*args.step_length+step_i, xp=[0, args.episode_length*args.step_length/2],
                                fp=[args.epsilon_start, args.epsilon_end])
            random_sample = random.random()
            if random_sample <= epsilon:
                action = env.action_space.sample()
            else:
                # 将离散状态转换为one-hot编码
                state_one_hot = np.zeros(state_dim)
                state_one_hot[state] = 1
                action = agent.get_action(state_one_hot)

            next_state_raw, reward, terminated, truncated, info_ = env.step(action)
            next_state = next_state_raw
            
            # 将离散状态转换为one-hot编码用于存储
            state_one_hot = np.zeros(state_dim)
            state_one_hot[state] = 1
            next_state_one_hot = np.zeros(state_dim)
            next_state_one_hot[next_state] = 1
            
            agent.memory.store_transition(state_one_hot, action, next_state_one_hot, reward, terminated or truncated)
            agent.update()

            state = next_state
            episode_reward += reward
            if terminated or truncated:
                break

        print(f"Episode: {episode_i+1}, Reward: {round(episode_reward, 3)}")
        reward_list.append(episode_reward)

    # save model
    save_model(os.path.dirname(os.path.realpath(__file__)), agent.q_net.state_dict(), 'double_dqn_q')
    plot_reward(reward_list, 30, args.env_name)
    print(f"Training completed! Final rewards: {reward_list[-5:]}" )

    try:
        test_env = gym.make(args.env_name, render_mode="human")
    except Exception:
        test_env = gym.make(args.env_name)
    test_episodes = 3
    for episode_i in range(test_episodes):
        reset_ret = test_env.reset()
        if isinstance(reset_ret, tuple):
            state_raw, _ = reset_ret
        else:
            state_raw = reset_ret
        state = state_raw
        ep_reward = 0.0
        for _ in range(args.step_length):
            state_one_hot = np.zeros(state_dim)
            state_one_hot[state] = 1
            action = agent.get_action(state_one_hot)
            step_ret = test_env.step(action)
            if len(step_ret) == 5:
                next_state_raw, reward, terminated, truncated, _ = step_ret
                done = terminated or truncated
            else:
                next_state_raw, reward, done, _ = step_ret
            ep_reward += reward
            state = next_state_raw
            try:
                test_env.render()
            except Exception:
                pass
            if done:
                break
        print(f"Test Episode {episode_i+1}/{test_episodes}, Reward: {round(ep_reward, 3)}")
    test_env.close()
